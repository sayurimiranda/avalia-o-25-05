//import { PugAdapter } from "@nestjs-modules/mailer/dist/adapters/pug.adapter";
//import { MailerModule } from "@nestjs-modules/mailer";
import {
  MiddlewareConsumer,
  Module,
  NestModule,
  RequestMethod,
  forwardRef,
} from "@nestjs/common";
import { ConfigModule } from "@nestjs/config";
import { APP_GUARD } from "@nestjs/core";
import { ThrottlerModule, ThrottlerGuard } from "@nestjs/throttler";
import { AppController } from "./app.controller";
import { AppService } from "./app.service";
import { AuthModule } from "./configuration/auth/auth.module";
import { DisciplinaModule } from "./disciplina/disciplina.module";
import { EmpresaModule } from "./empresa/empresa.module";
import { UsuarioModule } from "./usuario/usuario.module";
import { ComentarioModule } from "./comentario/comentario.module";
import { PermissionamentoModule } from "./permissionamento/permissionamento.module";
import { MarkUpModule } from "./mark-up/mark-up.module";
import { NotificacaoModule } from "./notificacao/notificacao.module";
import { ArquivoModule } from "./arquivo/arquivo.module";
import { TagModule } from "./tag/tag.module";
import { RelatorioModule } from "./relatorio/relatorio.module";
import { ProjetoModule } from './projeto/projeto.module';
import { EtapaModule } from './etapa/etapa.module';
import { JwtGuard } from "./configuration/guards/jwt.guard";
import { RoleGuard } from "./configuration/guards/role.guard";
import { CacheModule } from "@nestjs/cache-manager";
import { ListaCompartilhadaModule } from './lista_compartilhada/lista_compartilhada.module';
import { GrupoModule } from "./grupo/grupo.module";
import { ProjetoUsuarioModule } from './projeto_usuario/projeto_usuario.module';

@Module({
  imports: [
    ConfigModule.forRoot(),
    ThrottlerModule.forRoot([
      {
        ttl: 60000,
        limit: 6,
      },
    ]),
    forwardRef(() => UsuarioModule),
    forwardRef(() => EmpresaModule),
    forwardRef(() => ComentarioModule),
    forwardRef(() => PermissionamentoModule),
    forwardRef(() => AuthModule),
    forwardRef(() => RelatorioModule),

    forwardRef(() => EtapaModule),
    //    MailerModule.forRoot({
    //      // https://ethereal.email/create
    //      transport: {
    //        host: "smtp.ethereal.email",
    //        port: 587,
    //        auth: {
    //          user: "blanche.kuvalis57@ethereal.email",
    //          pass: "aeGHbbpg3HFJThTrVx",
    //        },
    //      },
    //      defaults: {
    //        from: '"Mackenzie" <blanche.kuvalis57@ethereal.email>',
    //      },
    //      template: {
    //        dir: __dirname + "/templates",
    //        adapter: new PugAdapter(),
    //        options: {
    //          strict: true,
    //        },
    //      },
    //    }),
    DisciplinaModule,
    EmpresaModule,
    ComentarioModule,
    MarkUpModule,
    NotificacaoModule,
    ArquivoModule,
    ProjetoModule,
    EtapaModule,
    CacheModule.register({
      isGlobal: true
    }),
    ListaCompartilhadaModule,
    PermissionamentoModule,
    GrupoModule,
    EtapaModule,
    ProjetoUsuarioModule,
  ],
  controllers: [AppController],
  providers: [
    AppService,
    // {
    //   provide: APP_GUARD,
    //   useClass: JwtGuard,
    // },
    // {
    //   provide: APP_GUARD,
    //   useClass: RoleGuard,
    // }
  ],
  exports: [AppService],
})
export class AppModule implements NestModule {
  configure(consumer: MiddlewareConsumer) {
    consumer.apply().forRoutes({
      path: "users/:id",
      method: RequestMethod.ALL,
    });
  }
}
