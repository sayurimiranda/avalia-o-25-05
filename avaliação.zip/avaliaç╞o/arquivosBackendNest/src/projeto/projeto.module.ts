import { Module, forwardRef } from "@nestjs/common";
import { ProjetoService } from "./projeto.service";
import { ProjetoController } from "./projeto.controller";
import { PrismaModule } from "src/configuration/prisma/prisma.module";
import { AuthModule } from "src/configuration/auth/auth.module";

@Module({
  imports: [PrismaModule, forwardRef(() => AuthModule)],
  controllers: [ProjetoController],
  providers: [ProjetoService],
  exports: [ProjetoService],
})
export class ProjetoModule { }
