import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  Put,
  ParseIntPipe,
} from "@nestjs/common";
import { ProjetoService } from "./projeto.service";
import { CreateProjetoDto } from "./dto/create-projeto.dto";
import { ApiOperation } from "@nestjs/swagger";
import { UpdateProjetoDto } from "./dto/update-projeto.dto";

@Controller("projeto")
export class ProjetoController {
  constructor(private readonly projetoService: ProjetoService) { }

  @Post()
  async create(@Body() createProjetoaDto: CreateProjetoDto) {
    return this.projetoService.create(createProjetoaDto);
  }

  @Get()
  async findAll() {
    return this.projetoService.findAll();
  }

  @Get(":id")
  async findById(@Param("id") id: string) {
    return this.projetoService.findById(+id);
  }

  @Get('empresa/:empresa_id')
  @ApiOperation({ summary: "Projetos com o status ativo de uma empresa especifica" })
  async findByProjetosAtivosEmpresa(@Param('empresa_id') empresa_id: string) {
    return this.projetoService.findByProjetosAtivosEmpresa(+empresa_id);
  }

  @Patch(':id')
  async update(@Param('id') id: string, @Body() updateProjetoDto: UpdateProjetoDto) {
    return this.projetoService.update(+id, updateProjetoDto);
  }

  @Delete(':id')
  async delete(@Param('id') id: string) {
    return this.projetoService.delete(+id);
  }
}

