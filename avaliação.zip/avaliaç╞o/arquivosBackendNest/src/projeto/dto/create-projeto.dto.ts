import { ApiProperty } from "@nestjs/swagger";
import {
  IsDate,
  IsInt,
  IsOptional,
  IsString,
  MaxLength,
} from "class-validator";

export class CreateProjetoDto {
  @ApiProperty()
  @IsInt()
  empresa_id: number;

  @ApiProperty()
  @IsString()
  @IsOptional()
  @MaxLength(300)
  projeto_descricao: string;

  @ApiProperty()
  @IsOptional()
  @IsDate()
  projeto_data_inicio: Date;

  @ApiProperty()
  @IsOptional()
  @IsDate()
  projeto_data_fim: Date;

  @ApiProperty()
  @IsOptional()
  @IsInt()
  projeto_orcamento: number;


  @ApiProperty()
  @IsOptional()
  @IsInt()
  projeto_status: number;
}
