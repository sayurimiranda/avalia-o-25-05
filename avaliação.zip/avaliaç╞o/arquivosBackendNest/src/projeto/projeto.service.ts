import { Injectable, NotFoundException } from "@nestjs/common";
import { CreateProjetoDto } from "./dto/create-projeto.dto";
import { PrismaService } from "src/configuration/prisma/prisma.service";

@Injectable()
export class ProjetoService {
  constructor(private readonly prisma: PrismaService) { }

  async create(data: CreateProjetoDto) {
    return this.prisma.projeto.create({ data });
  }

  async findAll() {
    const projetos: any[] = await this.prisma.projeto.findMany();
    // Mapeia os resultados da consulta
    return projetos.map(projeto => ({
      ...projeto,
      // Converte o projeto_orcamento para Number
      projeto_orcamento: Number(projeto.projeto_orcamento),
    }));
  }

  async findById(id: number) {
    return this.prisma.projeto.findUnique({
      where: { projeto_id: id },
    }).then(projeto => ({
      ...projeto,
      // Converte o projeto_orcamento para Number
      projeto_orcamento: Number(projeto.projeto_orcamento),
    }));
  }

  async findByProjetosAtivosEmpresa(idEmpresa: number) {
    const projetos: any[] = await this.prisma.$queryRaw`
    SELECT projeto.*
    FROM projeto
    INNER JOIN empresa ON projeto.empresa_id = empresa.empresa_id
    WHERE empresa.empresa_id = ${idEmpresa}
    AND projeto.projeto_status = 1;
  `;
    // Mapeia os resultados da consulta
    return projetos.map(projeto => ({
      ...projeto,
      // Converte o projeto_orcamento para Number
      projeto_orcamento: Number(projeto.projeto_orcamento),
    }));
  }

  async update(id: number, data: any) {
    await this.exists(id);
    return this.prisma.projeto.update({
      data,
      where: {
        projeto_id: id,
      },
    });
  }

  async delete(id: number) {
    await this.exists(id);
    return this.prisma.projeto.delete({
      where: {
        projeto_id: id,
      },
    });
  }

  async exists(id: number) {
    if (
      !(await this.prisma.projeto.count({
        where: {
          projeto_id: id,
        },
      }))
    ) {
      throw new NotFoundException(`O projeto ${id} não existe.`);
    }
  }
}
