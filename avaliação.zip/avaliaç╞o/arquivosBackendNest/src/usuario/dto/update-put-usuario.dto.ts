import { CreateUsuarioDTO } from "./create-usuario.dto";

export class UpdatePutUsuarioDTO extends CreateUsuarioDTO{

}