import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { ProjetoUsuarioService } from './projeto_usuario.service';
import { CreateProjetoUsuarioDto } from './dto/create-projeto_usuario.dto';
import { UpdateProjetoUsuarioDto } from './dto/update-projeto_usuario.dto';

@Controller('projeto-usuario')
export class ProjetoUsuarioController {
  constructor(private projetoUsuarioService: ProjetoUsuarioService) { }

  @Post()
  async create(@Body() CreateProjetoUsuarioDto: CreateProjetoUsuarioDto) {
    return this.projetoUsuarioService.create(CreateProjetoUsuarioDto);
  }

  @Get()
  async findAll() {
    return this.projetoUsuarioService.findAll();
  }

  @Get(":id")
  async findById(@Param("id") id: String) {
    return this.projetoUsuarioService.findById(+id);
  }

  @Patch(':id')
  async update(@Param('id') id: string, @Body() UpdateProjetoUsuarioDto: UpdateProjetoUsuarioDto) {
    return this.projetoUsuarioService.update(+id, UpdateProjetoUsuarioDto);
  }

  @Delete(':id')
  async delete(@Param('id') id: string) {
    return this.projetoUsuarioService.delete(+id);
  }
}
