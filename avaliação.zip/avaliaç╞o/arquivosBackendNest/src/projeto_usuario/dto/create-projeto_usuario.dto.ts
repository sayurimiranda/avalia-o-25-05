import { ApiProperty } from "@nestjs/swagger";
import { IsInt, IsOptional } from "class-validator";

export class CreateProjetoUsuarioDto {
    @ApiProperty()
    @IsOptional()
    @IsInt()
    projeto_usuario_status: number;

    @ApiProperty()
    @IsInt()
    usuario_id: number;

    @ApiProperty()
    @IsInt()
    projeto_id: number;
}
