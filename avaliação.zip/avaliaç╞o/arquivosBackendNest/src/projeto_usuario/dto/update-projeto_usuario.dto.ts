import { PartialType } from '@nestjs/swagger';
import { CreateProjetoUsuarioDto } from './create-projeto_usuario.dto';

export class UpdateProjetoUsuarioDto extends PartialType(CreateProjetoUsuarioDto) {}
