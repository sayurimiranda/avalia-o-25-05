import { Module, forwardRef } from '@nestjs/common';
import { ProjetoUsuarioService } from './projeto_usuario.service';
import { ProjetoUsuarioController } from './projeto_usuario.controller';
import { PrismaModule } from 'src/configuration/prisma/prisma.module';
import { AuthModule } from 'src/configuration/auth/auth.module';

@Module({
  imports: [PrismaModule, forwardRef(() => AuthModule)],
  controllers: [ProjetoUsuarioController],
  providers: [ProjetoUsuarioService],
  exports: [ProjetoUsuarioService],
})
export class ProjetoUsuarioModule { }
