import { Injectable, NotFoundException } from '@nestjs/common';
import { CreateProjetoUsuarioDto } from './dto/create-projeto_usuario.dto';
import { UpdateProjetoUsuarioDto } from './dto/update-projeto_usuario.dto';
import { PrismaService } from 'src/configuration/prisma/prisma.service';

@Injectable()
export class ProjetoUsuarioService {
  constructor(private readonly prisma: PrismaService) { }

  async create(data: CreateProjetoUsuarioDto) {
    return this.prisma.projeto_usuario.create({ data });
  }

  async findAll() {
    return this.prisma.projeto_usuario.findMany({
      where: {
        projeto_usuario_status: {
          gte: 0
        }
      },
    });
  }

  async findById(id: number) {
    await this.exists(id);
    return this.prisma.projeto_usuario.findUnique({
      where: {
        projeto_usuario_id: id,
        projeto_usuario_status: {
          gte: 0
        }
      },
    });
  }

  async update(id: number, data: any) {
    await this.exists(id);
    return this.prisma.projeto_usuario.update({
      data,
      where: {
        projeto_usuario_id: id,
      },
    });
  }

  async delete(id: number) {
    await this.exists(id);
    return this.prisma.projeto_usuario.delete({
      where: {
        projeto_usuario_id: id,
      },
    });
  }

  async exists(id: number) {
    if (
      !(await this.prisma.projeto_usuario.count({
        where: {
          projeto_usuario_id: id,
        },
      }))
    ) {
      throw new NotFoundException(`A projeto usuario ${id} não existe.`);
    }
  }
}
