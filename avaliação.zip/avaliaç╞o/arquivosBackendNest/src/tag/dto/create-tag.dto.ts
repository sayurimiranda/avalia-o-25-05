import { ApiProperty } from "@nestjs/swagger";
export class CreateTagDto {
  @ApiProperty()
  tag_nome: string;
  @ApiProperty()
  projeto_id: number;
}
