import { Module } from "@nestjs/common";
import { TagService } from "./tag.service";
import { TagController } from "./tag.controller";
import { PrismaModule } from "src/configuration/prisma/prisma.module";

@Module({
  controllers: [TagController],
  imports: [PrismaModule],
  providers: [TagService],
})
export class TagModule {}
