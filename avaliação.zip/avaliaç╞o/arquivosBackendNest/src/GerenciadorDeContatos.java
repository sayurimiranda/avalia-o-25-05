import java.util.HashMap;
import java.util.Map;

// Conteúdo do arquivo GerenciadorDeContatos.java

public class GerenciadorDeContatos {
    private Map<Integer, Contato> contatos;

    public GerenciadorDeContatos() {
        this.contatos = new HashMap<>();
    }

    public void adicionarContato(int id, String nome, String telefone) {
        if (contatos.containsKey(id)) {
            throw new IllegalArgumentException("Contato com este ID já existe.");
        }
        Contato novoContato = new Contato(id, nome, telefone);
        contatos.put(id, novoContato);
    }

    public void removerContato(int id) {
        if (!contatos.containsKey(id)) {
            throw new IllegalArgumentException("Contato com este ID não existe.");
        }
        contatos.remove(id);
    }

    public Contato pesquisarContatoPorId(int id) {
        if (!contatos.containsKey(id)) {
            throw new IllegalArgumentException("Contato com este ID não existe.");
        }
        return contatos.get(id);
    }
}
