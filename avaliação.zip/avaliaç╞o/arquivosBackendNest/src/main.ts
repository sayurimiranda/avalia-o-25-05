import { NestFactory } from "@nestjs/core";
import { AppModule } from "./app.module";
import { ValidationPipe } from "@nestjs/common";
import { DocumentBuilder, SwaggerModule } from "@nestjs/swagger";
import { LogInterceptor } from "./configuration/interceptors/log.interceptor";

async function bootstrap() {
  const app = await NestFactory.create(AppModule);

  app.enableCors({
    origin: ["http://localhost:4200", "*"],
    methods: ["GET", "POST", "PUT", "PATCH", "DELETE"],
  });

  app.useGlobalPipes(new ValidationPipe());

  app.useGlobalInterceptors(new LogInterceptor());

  const config = new DocumentBuilder()
    .setTitle("Senac RJ Faculdade - Projeto Integrador Conjunto")
    .setDescription("ArquivoProjetos")
    .setVersion("1.0")
    .addTag("arquivos")
    // .addBearerAuth({
    //   type: 'http',
    //   scheme: 'bearer',
    //   bearerFormat: 'JWT',
    //   in: 'header',
    //   name: 'Authorization',
    //   description: 'Enter your Bearer token',
    //   })
    // .addSecurityRequirements('bearer')
    .build();
  const document = SwaggerModule.createDocument(app, config);
  SwaggerModule.setup("api", app, document);

  await app.listen(3000);
}
bootstrap();
