import { Injectable, NotFoundException } from "@nestjs/common";
import { PrismaService } from "../configuration/prisma/prisma.service";
import { CreateGrupoDto } from "./dto/create-grupo.dto";

@Injectable()
export class GrupoService {
  constructor(private readonly prisma: PrismaService) { }

  async create(data: CreateGrupoDto) {
    const createdGrupo = await this.prisma.grupo.create({ data });
    return createdGrupo;
  }

  async findUsuario(usuario_id: number) {
    return this.prisma.$queryRaw`SELECT *
        FROM grupo AS gp
        JOIN permissionamento AS p ON gp.grupo_id = p.grupo_id
        JOIN usuario AS u ON p.usuario_id = u.usuario_id
        LEFT JOIN arquivo AS a ON p.arquivo_id = a.arquivo_id
        LEFT JOIN etapa AS e ON p.etapa_id = e.etapa_id
        LEFT JOIN disciplina AS d ON p.disciplina_id = d.disciplina_id
        LEFT JOIN projeto AS pro ON p.projeto_id = pro.projeto_id
        WHERE u.usuario_id ${usuario_id};
    `;
  }

  async findGrupo(usuario_id: number, grupo_id: number) {
    return this.prisma.$queryRaw`SELECT *
      FROM grupo AS gp
      JOIN permissionamento AS p ON gp.grupo_id = p.grupo_id
      JOIN usuario_grupo AS ug ON p.usuario_grupo_id = ug.usuario_grupo_id
      JOIN usuario AS u ON ug.usuario_id = u.usuario_id
      LEFT JOIN arquivo AS a ON p.arquivo_id = a.arquivo_id
      LEFT JOIN etapa AS e ON p.etapa_id = e.etapa_id
      LEFT JOIN disciplina AS d ON p.disciplina_id = d.disciplina_id
      LEFT JOIN projeto AS pro ON p.projeto_id = pro.projeto_id
      WHERE u.usuario_id = ${usuario_id}
      AND gp.grupo_id = ${grupo_id};
    `;
  }

  async findAll() {
    return this.prisma.grupo.findMany({
      where: {
        grupo_status: {
          gte: 0,
        },
      }
    });
  }

  async findOne(id: number) {
    const grupo = await this.ensureGrupoExists(id);
    return grupo;
  }

  async update(id: number, data: Partial<CreateGrupoDto>) {
    await this.ensureGrupoExists(id);
    return this.prisma.grupo.update({
      where: { grupo_id: id },
      data,
    });
  }

  async remove(id: number) {
    await this.ensureGrupoExists(id);
    return this.prisma.grupo.update({
      where: { grupo_id: id },
      data: {
        grupo_status: -1,
      },
    });
  }

  private async ensureGrupoExists(id: number) {
    const grupo = await this.prisma.grupo.findUnique({
      where: { grupo_id: id },
    });
    if (!grupo) {
      throw new NotFoundException(`O grupo com ID ${id} não foi encontrado.`);
    }
    return grupo;
  }
}
