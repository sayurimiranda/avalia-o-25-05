export class CreateGrupoDto {}
