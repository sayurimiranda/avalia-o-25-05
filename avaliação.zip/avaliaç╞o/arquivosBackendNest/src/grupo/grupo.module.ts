import { Module } from "@nestjs/common";
import { PrismaModule } from "src/configuration/prisma/prisma.module"; // Verifique o caminho correto
import { GrupoService } from "./grupo.service";
import { GrupoController } from "./grupo.controller";

@Module({
  imports: [PrismaModule], // Importe o PrismaModule aqui
  controllers: [GrupoController],
  providers: [GrupoService],
})
export class GrupoModule {}
