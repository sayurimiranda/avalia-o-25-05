import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
} from "@nestjs/common";
import { GrupoService } from "./grupo.service";
import { CreateGrupoDto } from "./dto/create-grupo.dto";
import { UpdateGrupoDto } from "./dto/update-grupo.dto";

@Controller("grupo")
export class GrupoController {
  constructor(private readonly grupoService: GrupoService) { }

  @Post()
  create(@Body() createGrupoDto: CreateGrupoDto) {
    return this.grupoService.create(createGrupoDto);
  }

  @Get(":usuario_id/:grupo_id")
  findGrupo(
    @Param("grupo_id") grupo_id: number,
    @Param("usuario_id") usuario_id: number,
  ) {
    return this.grupoService.findGrupo(usuario_id, grupo_id);
  }

  @Get(":usuario_id")
  findUsuario(@Param("usuario_id") usuario_id: number) {
    return this.grupoService.findUsuario(usuario_id);
  }

  @Get()
  findAll() {
    return this.grupoService.findAll();
  }

  @Get(":id")
  findOne(@Param("id") id: number) {
    return this.grupoService.findOne(id);
  }

  @Patch(":id")
  update(@Param("id") id: number, @Body() updateGrupoDto: UpdateGrupoDto) {
    return this.grupoService.update(id, updateGrupoDto);
  }

  @Delete(":id")
  remove(@Param("id") id: number) {
    return this.grupoService.remove(id);
  }
}
