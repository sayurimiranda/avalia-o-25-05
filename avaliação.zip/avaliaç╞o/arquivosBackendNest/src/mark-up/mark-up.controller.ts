import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
} from "@nestjs/common";
import { MarkUpService } from "./mark-up.service";
import { CreateMarkUpDto } from "./dto/create-mark-up.dto";
import { UpdateMarkUpDto } from "./dto/update-mark-up.dto";
import { CreateComentarioDto } from "src/comentario/dto/create-comentario.dto";

@Controller("markup")
export class MarkUpController {
  constructor(private readonly markUpService: MarkUpService) {}

  @Post()
  create(@Body() createMarckupDto: CreateMarkUpDto) {
    return this.markUpService.create(createMarckupDto);
  }

  // @Post("markup-comentario")
  // createMarkup(
  //   @Body()
  //   createDto: {
  //     createComentarioDto: CreateComentarioDto;
  //     createMarckupDto: CreateMarkUpDto;
  //   },
  // ) {
  //   return this.markUpService.createMarckupComentario(createDto);
  // }

  @Get()
  findAll() {
    return this.markUpService.findAll();
  }

  @Get(":id")
  findOne(@Param("id") id: string) {
    return this.markUpService.findOne(+id);
  }

  @Patch(":id")
  update(@Param("id") id: string, @Body() updateMarckupDto: UpdateMarkUpDto) {
    return this.markUpService.update(+id, updateMarckupDto);
  }

  @Delete(":id")
  remove(@Param("id") id: string) {
    return this.markUpService.remove(+id);
  }
}
