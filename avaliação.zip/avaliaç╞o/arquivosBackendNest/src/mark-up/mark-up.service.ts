import { Injectable } from "@nestjs/common";
import { CreateMarkUpDto } from "./dto/create-mark-up.dto";
import { UpdateMarkUpDto } from "./dto/update-mark-up.dto";
import { PrismaService } from "src/configuration/prisma/prisma.service";
import { ComentarioService } from "src/comentario/comentario.service";
import { CreateComentarioDto } from "src/comentario/dto/create-comentario.dto";

@Injectable()
export class MarkUpService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly comentarioService: ComentarioService,
  ) {}

  //novo markup
  create(createMarckupDto: CreateMarkUpDto) {
    return this.prisma.arquivo_comentario_markup.create({
      data: createMarckupDto,
    });
  }
  // Criar Primeiro marckup
  // Deve ser criado um comentario antes de criar um marckup
  // async createMarckupComentario({
  //   createComentarioDto,
  //   createMarckupDto,
  // }: {
  //   createComentarioDto: CreateComentarioDto;
  //   createMarckupDto: CreateMarkUpDto;
  // }) {
  //   const response = await this.comentarioService.create(createComentarioDto);
  //   return this.prisma.arquivo_comentario_markup.create({
  //     data: {
  //       ...createMarckupDto,
  //       arquivo_comentario_id: response.arquivo_comentario_id,
  //     },
  //   });
  // }

  findAll() {
    return this.prisma.arquivo_comentario_markup.findMany();
  }

  findOne(id: number) {
    return this.prisma.arquivo_comentario_markup.findUnique({
      where: {
        arquivo_comentario_markup_id: id,
      },
    });
  }

  update(id: number, updateMarkupDto: UpdateMarkUpDto) {
    return this.prisma.arquivo_comentario_markup.update({
      where: {
        arquivo_comentario_markup_id: id,
      },
      data: updateMarkupDto,
    });
  }

  remove(id: number) {
    return this.prisma.arquivo_comentario_markup.delete({
      where: {
        arquivo_comentario_markup_id: id,
      },
    });
  }
}
