import { PartialType } from "@nestjs/swagger";
import { CreateMarkUpDto } from "./create-mark-up.dto";

export class UpdateMarkUpDto extends PartialType(CreateMarkUpDto) {}
