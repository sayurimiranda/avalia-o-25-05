import { ApiProperty } from "@nestjs/swagger";

export class CreateMarkUpDto {
  @ApiProperty()
  arquivo_comentario_markup_id: number;

  @ApiProperty()
  arquivo_comentario_markup_link_s3?: string;

  @ApiProperty()
  arquivo_comentario_markup_descricao?: string;

  @ApiProperty()
  arquivo_comentario_id: number;

  @ApiProperty()
  arquivo_comentario_markup_data: Date;
}
