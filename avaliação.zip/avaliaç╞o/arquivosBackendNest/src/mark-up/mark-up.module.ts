import { Module } from "@nestjs/common";
import { MarkUpService } from "./mark-up.service";
import { MarkUpController } from "./mark-up.controller";
import { ComentarioModule } from "src/comentario/comentario.module";
import { PrismaModule } from "src/configuration/prisma/prisma.module";

@Module({
  controllers: [MarkUpController],
  imports: [PrismaModule, ComentarioModule],
  providers: [MarkUpService],
})
export class MarkUpModule {}
