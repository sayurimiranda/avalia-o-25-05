import { ApiProperty } from "@nestjs/swagger";
import { IsInt, IsOptional, IsString, MaxLength } from "class-validator";

export class CreateDisciplinaDto {
  @ApiProperty()
  @IsString()
  @MaxLength(300)
  disciplina_descricao: string;

  @ApiProperty()
  @IsOptional()
  @IsInt()
  disciplina_status: number;

  @ApiProperty()
  @IsOptional()
  @IsInt()
  projeto_id: number;
}
