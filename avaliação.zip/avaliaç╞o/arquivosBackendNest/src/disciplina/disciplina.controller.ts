import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  Put,
  ParseIntPipe,
} from "@nestjs/common";
import { DisciplinaService } from "./disciplina.service";
import { CreateDisciplinaDto } from "./dto/create-disciplina.dto";
import { UpdateDisciplinaDto } from "./dto/update-disciplina.dto";
import { ApiOperation } from "@nestjs/swagger";

@Controller("disciplina")
export class DisciplinaController {
  constructor(private disciplinaService: DisciplinaService) { }

  @Post()
  async create(@Body() createDisciplinaDto: CreateDisciplinaDto) {
    return this.disciplinaService.create(createDisciplinaDto);
  }
  
  @Get()
  async findAll() {
    return this.disciplinaService.findAll();
  }

  @Get(":id")
  async findById(@Param("id") id: String) {
    return this.disciplinaService.findById(+id);
  }

  @Get('projeto/:projeto_id')
  @ApiOperation({ summary: "Disciplinas com o status ativo de um projeto específico" })
  async findByDisciplinasAtivasProjeto(@Param('projeto_id') projeto_id: string) {
    return this.disciplinaService.findByDisciplinasAtivasProjeto(+projeto_id);
  }

  @Patch(':id')
  async update(@Param('id') id: string, @Body() updateDiscplinaDto: UpdateDisciplinaDto) {
    return this.disciplinaService.update(+id, updateDiscplinaDto);
  }

  @Delete(':id')
  async delete(@Param('id') id: string) {
    return this.disciplinaService.delete(+id);
  }
}
