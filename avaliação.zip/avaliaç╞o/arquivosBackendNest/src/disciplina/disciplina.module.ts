import { Module, forwardRef } from "@nestjs/common";
import { DisciplinaService } from "./disciplina.service";
import { DisciplinaController } from "./disciplina.controller";
import { PrismaModule } from "src/configuration/prisma/prisma.module";
import { AuthModule } from "src/configuration/auth/auth.module";

@Module({
  imports: [PrismaModule, forwardRef(() => AuthModule)],
  controllers: [DisciplinaController],
  providers: [DisciplinaService],
  exports: [DisciplinaService],
})
export class DisciplinaModule {}
