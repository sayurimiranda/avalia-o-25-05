import { Injectable, NotFoundException } from "@nestjs/common";
import { CreateDisciplinaDto } from "./dto/create-disciplina.dto";
import { PrismaService } from "src/configuration/prisma/prisma.service";

@Injectable()
export class DisciplinaService {
  constructor(private readonly prisma: PrismaService) { }

  async create(data: CreateDisciplinaDto) {
    return this.prisma.disciplina.create({ data });
  }

  async findAll() {
    return this.prisma.disciplina.findMany({
      where: {
        disciplina_status: {
          gte: 0
        }
      },
    });
  }

  async findById(id: number) {
    await this.exists(id);
    return this.prisma.disciplina.findUnique({
      where: {
        disciplina_id: id,
        disciplina_status: {
          gte: 0
        }
      },
    });
  }

  async findByDisciplinasAtivasProjeto(
    idProjeto: number,
  ) {
    return this.prisma.$queryRaw`
    SELECT disciplina.*
    FROM disciplina
    INNER JOIN projeto ON projeto.projeto_id = disciplina.projeto_id
    WHERE projeto.projeto_id = ${idProjeto}
    AND disciplina.disciplina_status >= 0;
`;
  }

  async update(id: number, data: any) {
    await this.exists(id);
    return this.prisma.disciplina.update({
      data,
      where: {
        disciplina_id: id,
      },
    });
  }

  async delete(id: number) {
    await this.exists(id);
    return this.prisma.disciplina.delete({
      where: {
        disciplina_id: id,
      },
    });
  }

  async exists(id: number) {
    if (
      !(await this.prisma.disciplina.count({
        where: {
          disciplina_id: id,
        },
      }))
    ) {
      throw new NotFoundException(`A disciplina ${id} não existe.`);
    }
  }
}