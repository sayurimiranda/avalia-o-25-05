import { Injectable, NotFoundException } from "@nestjs/common";
import { PrismaService } from "../configuration/prisma/prisma.service";
import { CreateEmpresaDto } from "./dto/create-empresa.dto";

@Injectable()
export class EmpresaService {

  constructor(private readonly prisma: PrismaService) { }

  async create(data: CreateEmpresaDto) {
    return this.prisma.empresa.create({ data });
  }

  async findAll() {
    return this.prisma.empresa.findMany({
      where: {
        empresa_status: {
          gte: 0
        },
      },
    });
  }

  async findById(id: number) {
    await this.exists(id);
    return this.prisma.empresa.findUnique({
      where: {
        empresa_id: id,
        empresa_status: {
          gte: 0
        }
      },
    });
  }

  async updatePut(id: number, data: any) {
    await this.exists(id);
    return this.prisma.empresa.update({
      data,
      where: {
        empresa_id: id,
      },
    });
  }

  async updatePatch(id: number, data: any) {
    await this.exists(id);
    return this.prisma.empresa.update({
      data,
      where: {
        empresa_id: id,
      },
    });
  }

  async delete(id: number) {
    await this.exists(id);
    return this.prisma.empresa.update({
      data: {
        empresa_status: -1
      },
      where: {
        empresa_id: id,
      },
    });
  }

  async exists(id: number) {
    if (
      !(await this.prisma.empresa.count({
        where: {
          empresa_id: id,
        },
      }))
    ) {
      throw new NotFoundException(`A empresa ${id} não existe.`);
    }
  }
}
