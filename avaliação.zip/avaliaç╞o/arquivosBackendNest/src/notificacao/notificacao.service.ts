import { Injectable } from "@nestjs/common";
import { CreateNotificacaoDto } from "./dto/create-notificacao.dto";
import { UpdateNotificacaoDto } from "./dto/update-notificacao.dto";
import { PrismaService } from "src/configuration/prisma/prisma.service";
import { NotFoundException } from "@nestjs/common";

@Injectable()
export class NotificacaoService {
  constructor(private readonly prisma: PrismaService) { }

  async create(createNotificacaoDto: CreateNotificacaoDto) {
    const response = await this.prisma.notificacao.create({
      data: createNotificacaoDto,
    });
    if (!response) {
      throw new NotFoundException("Erro ao criar Notificação");
    }
    return response;
  }
  // Função para buscar todas as notificações de um usuário exeto as deletadas
  // 1 - Notificação não lida
  // 2 - Notificação lida
  async findAllbyUser(id: number) {
    const response = await this.prisma.notificacao.findMany({
      where: {
        usuario_id: id,
        notificacao_status: {
          in: [1, 2],
        },
      },
      include: {
        usuario: {
          select: {
            usuario_nome: true,
            usuario_links3_foto: true,
          },
        },
      },
    });
    if (!response) {
      throw new NotFoundException("Notificação não encontrada");
    }
    return response;
  }

  async newNotification(id: number) {
    const response = await this.prisma.notificacao.findMany({
      where: { usuario_id: id, notificacao_status: 1 },
      include: {
        usuario: {
          select: {
            usuario_nome: true,
            usuario_links3_foto: true,
          },
        },
      },
    });
    if (!response) {
      throw new NotFoundException("Notificação não encontrada");
    }
    return response;
  }

  // Função para alterar o status da notificação
  //    0 - lida Notificação Deletada
  //    1 - Notificação não
  //    2 - Notificação lida
  async update(id: number, updateNotificacaoDto: UpdateNotificacaoDto) {
    const response = await this.prisma.notificacao.update({
      where: { notificacao_id: id },
      data: { notificacao_status: -1 },
    });
    if (!response) {
      throw new NotFoundException("Erro ao alterar Notificação");
    }
    return response;
  }
  // --------- --- - funções sem uso no sistema - --- ---------
  remove(id: number) {
    return this.prisma.notificacao.delete({
      where: { notificacao_id: id },
    });
  }
  deleteLogico(id: number) {
    return this.prisma.notificacao.update({
      where: { notificacao_id: id },
      data: { notificacao_status: -1 },
    });
  }
  updateCiente(id: number) {
    return this.prisma.notificacao.update({
      where: { notificacao_id: id },
      data: { notificacao_status: 2 },
    });
  }
}
