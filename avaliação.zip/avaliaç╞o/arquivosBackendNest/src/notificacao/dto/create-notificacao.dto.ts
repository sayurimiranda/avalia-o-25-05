import { ApiProperty } from "@nestjs/swagger";
export class CreateNotificacaoDto {
  @ApiProperty()
  notificacao_data?: Date;

  @ApiProperty()
  notificacao_status?: number;

  @ApiProperty()
  usuario_id: number;

  @ApiProperty()
  notificacao_titulo: string;

  @ApiProperty()
  notificacao_descricao: string;
}
