import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
} from "@nestjs/common";
import { NotificacaoService } from "./notificacao.service";
import { CreateNotificacaoDto } from "./dto/create-notificacao.dto";
import { UpdateNotificacaoDto } from "./dto/update-notificacao.dto";

@Controller("notificacao")
export class NotificacaoController {
  constructor(private readonly notificacaoService: NotificacaoService) {}

  @Post()
  create(@Body() createNotificacaoDto: CreateNotificacaoDto) {
    return this.notificacaoService.create(createNotificacaoDto);
  }

  @Get(":usuario_id")
  findAllByUser(@Param("usuario_id") id: string) {
    return this.notificacaoService.findAllbyUser(+id);
  }

  @Get("naolidas/:usuario_id")
  newNotification(@Param("usuario_id") id: string) {
    return this.notificacaoService.newNotification(+id);
  }

  @Get("updateciente/:id")
  updateCiente(@Param("id") id: string) {
    return this.notificacaoService.updateCiente(+id);
  }

  @Patch(":id")
  update(
    @Param("id") id: string,
    @Body() updateNotificacaoDto: UpdateNotificacaoDto,
  ) {
    return this.notificacaoService.update(+id, updateNotificacaoDto);
  }

  @Get("delete/:id")
  deleteLogico(@Param("id") id: string) {
    return this.notificacaoService.deleteLogico(+id);
  }

  @Delete(":id")
  remove(@Param("id") id: string) {
    return this.notificacaoService.remove(+id);
  }
}
