import { Module } from "@nestjs/common";
import { NotificacaoService } from "./notificacao.service";
import { NotificacaoController } from "./notificacao.controller";
import { PrismaModule } from "src/configuration/prisma/prisma.module";

@Module({
  controllers: [NotificacaoController],
  imports: [PrismaModule],
  providers: [NotificacaoService],
})
export class NotificacaoModule {}
