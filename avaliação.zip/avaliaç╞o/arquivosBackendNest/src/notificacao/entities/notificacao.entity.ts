export class Notificacao {}
