import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
} from "@nestjs/common";
import { ComentarioService } from "./comentario.service";
import { CreateComentarioDto } from "./dto/create-comentario.dto";
import { UpdateComentarioDto } from "./dto/update-comentario.dto";

@Controller("comentario")
export class ComentarioController {
  constructor(private readonly comentarioService: ComentarioService) {}

  @Post()
  create(@Body() createComentarioDto: CreateComentarioDto) {
    return this.comentarioService.create(createComentarioDto);
  }

  @Get()
  findAll() {
    return this.comentarioService.findAll();
  }

  @Get("arquivo/:arquivo_id")
  findAllByUser(@Param("arquivo_id") id: string) {
    return this.comentarioService.findAllByAquivoIdChildren(id);
  }

  @Get(":id")
  findOne(@Param("id") id: string) {
    return this.comentarioService.findOne(+id);
  }

  @Get(":id/children")
  findOneWithChildren(@Param("id") id: string) {
    return this.comentarioService.findOneWithChildren(+id);
  }

  @Patch(":id")
  update(
    @Param("id") id: number,
    @Body() updateComentarioDto: UpdateComentarioDto,
  ) {
    return this.comentarioService.update(+id, updateComentarioDto);
  }

  @Get("delete/:id")
  delete(@Param("id") id: number) {
    return this.comentarioService.DeleteAt(+id);
  }

  @Delete(":id")
  remove(@Param("id") id: string) {
    return this.comentarioService.remove(+id);
  }
}
