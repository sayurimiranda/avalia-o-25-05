import { Injectable } from "@nestjs/common";
import { CreateComentarioDto } from "./dto/create-comentario.dto";
import { UpdateComentarioDto } from "./dto/update-comentario.dto";
import { PrismaService } from "src/configuration/prisma/prisma.service";
import { NotFoundException } from "@nestjs/common";

@Injectable()
export class ComentarioService {
  constructor(private readonly prisma: PrismaService) { }
  // Cria um novo comentário
  async create(createComentarioDto: CreateComentarioDto) {
    createComentarioDto.arquivo_comentario_status = 1;
    createComentarioDto.arquivo_comentario_data = new Date();
    const novoComentario = await this.prisma.arquivo_comentario.create({
      data: createComentarioDto,
    });
    if (!novoComentario) {
      throw new NotFoundException(" Erro ao inserir Comentário");
    }

    return novoComentario;
  }

  async findAllByAquivoIdChildren(arquivoPaiID: string) {
    const arquivos = await this.prisma.arquivo.findMany({
      where: {
        OR: [{ arquivo_id: arquivoPaiID }, { arquivo_id_pai: arquivoPaiID }],
      },
      include: {
        arquivo_comentario: {
          where: {
            arquivo_comentario_status: 1,
          },
          include: {
            usuario: {
              select: {
                usuario_nome: true,
                usuario_id: true,
                usuario_links3_foto: true,
              },
            },
          },
        },
      },
      orderBy: {
        arquivo_versao: "asc", // ou 'desc' para ordem decrescente
      },
    });

    if (!arquivos) {
      throw new NotFoundException(
        "Arquivos e comentários aninhados não encontrado",
      );
    }

    // Filtrar arquivos que têm comentários
    const arquivosComComentarios = arquivos.filter(
      (arquivo) =>
        arquivo.arquivo_comentario && arquivo.arquivo_comentario.length > 0,
    );

    return arquivosComComentarios;
  }

  //Listar todos os comentarios de um arquivo e seus comentarios aninhados
  // async findAllByAquivoIdChildren(id: string) {
  //   const response = await this.prisma.arquivo.findFirst({
  //     where: {
  //       arquivo_id: id,
  //     },
  //     include: {
  //       arquivo_comentario: {
  //         where: {
  //           arquivo_comentario_status: 1,
  //           arquivo_comentario_id_pai: null,
  //         },
  //       },
  //     },
  //   });
  //   if (!response) {
  //     throw new NotFoundException(
  //       "Arquivos e comentários aninhados não encontrado",
  //     );
  //   }

  //   const comentariosComFilhos = await Promise.all(
  //     response.arquivo_comentario.map(async (comentario) => {
  //       const filho = await this.findOneWithChildren(
  //         comentario.arquivo_comentario_id,
  //       );
  //       return {
  //         ...comentario,
  //         children: filho.children,
  //       };
  //     }),
  //   );

  //   response.arquivo_comentario = comentariosComFilhos;

  //   return response;
  // }

  // Retorna um Comentário por id do comentário
  async findOne(id: number) {
    const response = await this.prisma.arquivo_comentario.findUnique({
      where: {
        arquivo_comentario_id: id,
      },
    });
    if (!response) {
      throw new NotFoundException(" comentário não encontrado");
    }
    return response;
  }

  async update(id: number, updateComentarioDto: UpdateComentarioDto) {
    const response = await this.prisma.arquivo_comentario.update({
      where: {
        arquivo_comentario_id: id,
      },
      data: updateComentarioDto,
    });
    if (!response) {
      throw new NotFoundException("Erro ao Editar Comentário");
    }
    return response;
  }

  async DeleteAt(id: number) {
    const response = await this.prisma.arquivo_comentario.update({
      where: {
        arquivo_comentario_id: id,
      },
      data: {
        arquivo_comentario_status: 0,
      },
    });
    if (!response) {
      throw new NotFoundException("Erro ao Editar Comentário");
    }
    return response;
  }

  // Funções sem uso -------------------------------

  //Listar um os comentarios por id  e seus comentarios filhos
  async findOneWithChildren(id: number) {
    const comentarioPai = await this.prisma.arquivo_comentario.findUnique({
      where: {
        arquivo_comentario_id: id,
      },
    });

    const comentariosFilhos = await this.prisma.arquivo_comentario.findMany({
      where: {
        arquivo_comentario_id_pai: id,
      },
    });
    if (!comentarioPai || !comentariosFilhos) {
      throw new NotFoundException(
        "Arquivos e comentários aninhados não encontrado",
      );
    }
    return {
      ...comentarioPai,
      children: comentariosFilhos,
    };
  }

  // Remove definitivamente um comentário
  async remove(id: number) {
    const response = this.prisma.arquivo_comentario.delete({
      where: {
        arquivo_comentario_id: id,
      },
    });

    if (!response) {
      throw new NotFoundException("Erro Ao deletar Comentário");
    }
    return response;
  }

  // Listar Todos os comentários
  findAll() {
    return this.prisma.arquivo_comentario.findMany();
  }
}
