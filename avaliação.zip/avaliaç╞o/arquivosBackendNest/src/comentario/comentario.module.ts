import { Module } from "@nestjs/common";
import { ComentarioService } from "./comentario.service";
import { ComentarioController } from "./comentario.controller";
import { PrismaModule } from "src/configuration/prisma/prisma.module";

@Module({
  controllers: [ComentarioController],
  imports: [PrismaModule],
  providers: [ComentarioService],
  exports: [ComentarioService],
})
export class ComentarioModule {}
