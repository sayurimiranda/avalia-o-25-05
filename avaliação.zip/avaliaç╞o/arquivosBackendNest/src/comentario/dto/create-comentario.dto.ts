import { IsInt, IsString, IsOptional, IsDate } from "class-validator";
import { ApiProperty } from "@nestjs/swagger";
// arquivo-comentario.dto.ts

export class CreateComentarioDto {
  @ApiProperty()
  arquivo_comentario_id: number;

  @ApiProperty()
  @IsString()
  @IsOptional()
  arquivo_comentario_descricao?: string;

  @IsInt()
  @IsOptional()
  @ApiProperty()
  arquivo_comentario_markup?: number;

  @IsString()
  @ApiProperty()
  arquivo_id: string;

  @IsInt()
  @IsOptional()
  @ApiProperty()
  arquivo_comentario_id_pai?: number;

  @IsInt()
  @IsOptional()
  @ApiProperty()
  arquivo_comentario_nivel?: number;

  @IsDate()
  @IsOptional()
  @ApiProperty()
  arquivo_comentario_data: Date;

  @IsInt()
  @IsOptional()
  @ApiProperty()
  arquivo_comentario_status?: number;

  @ApiProperty()
  @IsInt()
  usuario_id: number;
}
