export class Etapa {}
