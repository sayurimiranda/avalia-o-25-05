import { Module, forwardRef } from '@nestjs/common';
import { EtapaService } from './etapa.service';
import { EtapaController } from './etapa.controller';
import { PrismaModule } from 'src/configuration/prisma/prisma.module';
import { AuthModule } from 'src/configuration/auth/auth.module';

@Module({
  imports: [PrismaModule, forwardRef(() => AuthModule)],
  controllers: [EtapaController],
  providers: [EtapaService],
  exports: [EtapaService],
})
export class EtapaModule { }
