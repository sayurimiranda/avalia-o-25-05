import { Controller, Get, Post, Body, Patch, Param, Delete, Put, ParseIntPipe } from '@nestjs/common';
import { EtapaService } from './etapa.service';
import { CreateEtapaDto } from './dto/create-etapa.dto';
import { UpdateEtapaDto } from './dto/update-etapa.dto';
import { ApiOperation } from '@nestjs/swagger';

@Controller('etapa')
export class EtapaController {
  constructor(private etapaService: EtapaService) { }

  @Post()
  async create(@Body() createEtapaDto: CreateEtapaDto) {
    return this.etapaService.create(createEtapaDto);
  }

  @Get()
  async findAll() {
    return this.etapaService.findAll();
  }

  @Get(":id")
  async FindById(@Param("id") id: number) {
    return this.etapaService.findById(id);
  }

  @Get('disciplina/:disciplina_id')
  @ApiOperation({ summary: "Etapas com o status inativo de uma disciplina específica" })
  async findByEtapasAivasDisciplina(@Param('disciplina_id') disciplina_id: string) {
    return this.etapaService.findByEtapasAivasDisciplina(+disciplina_id);
  }

  @Patch(':id')
  async update(@Param('id') id: string, @Body() updateEtapaDto: UpdateEtapaDto) {
    return this.etapaService.update(+id, updateEtapaDto);
  }

  @Delete(':id')
  async delete(@Param('id') id: string) {
    return this.etapaService.delete(+id);

  }
}
