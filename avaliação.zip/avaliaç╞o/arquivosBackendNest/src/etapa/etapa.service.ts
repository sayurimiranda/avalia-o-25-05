import { Injectable, NotFoundException } from '@nestjs/common';
import { CreateEtapaDto } from './dto/create-etapa.dto';
import { UpdateEtapaDto } from './dto/update-etapa.dto';
import { PrismaService } from 'src/configuration/prisma/prisma.service';

@Injectable()
export class EtapaService {
  constructor(private readonly prisma: PrismaService) { }

  async create(data: CreateEtapaDto) {
    return this.prisma.etapa.create({ data });
  }

  async findAll() {
    return this.prisma.etapa.findMany({
      where: {
        etapa_status: {
          gte: 0,
        },
      }
    });
  }

  async findById(id: number) {
    await this.exists(id);
    return this.prisma.etapa.findUnique({
      where: {
        etapa_id: id,
        etapa_status: {
          gte: 0,
        }
      },
    });
  }

  async findByEtapasAivasDisciplina(
    idDisciplina: number,
  ) {
    return this.prisma.$queryRaw`
    SELECT etapa.*
    FROM etapa
    INNER JOIN disciplina ON etapa.disciplina_id = disciplina.disciplina_id
    WHERE disciplina.disciplina_id = ${idDisciplina}
    AND etapa.etapa_status >= 0;
`;
  }

  async update(id: number, data: any) {
    await this.exists(id);
    return this.prisma.etapa.update({
      data,
      where: {
        etapa_id: id,
      },
    });
  }

  async delete(id: number) {
    await this.exists(id);
    return this.prisma.etapa.update({
      where: {
        etapa_id: id,
      },
      data: {
        etapa_status: -1
      },
    });
  }

  async exists(id: number) {
    if (
      !(await this.prisma.etapa.count({
        where: {
          etapa_id: id,
        },
      }))
    ) {
      throw new NotFoundException(`A etapa ${id} não existe.`);
    }
  }
}
