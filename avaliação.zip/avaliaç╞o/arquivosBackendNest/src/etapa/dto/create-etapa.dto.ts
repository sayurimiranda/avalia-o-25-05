import { ApiProperty } from "@nestjs/swagger";
import { IsInt, IsOptional, IsString, MaxLength } from "class-validator";

export class CreateEtapaDto {
    @ApiProperty()
    @IsString()
    @IsOptional()
    @MaxLength(300)
    etapa_descricao: string;

    @ApiProperty()
    @IsInt()
    @IsOptional()
    etapa_data_inicio: Date;

    @ApiProperty()
    @IsInt()
    @IsOptional()
    etapa_data_fim: Date;

    @ApiProperty()
    @IsInt()
    @IsOptional()
    etapa_ordem: number;

    @ApiProperty()
    @IsOptional()
    @IsInt()
    etapa_status: number;

    @ApiProperty()
    @IsInt()
    disciplina_id: number;

    @ApiProperty()
    @IsInt()
    disciplina_id_pai: number;

}
