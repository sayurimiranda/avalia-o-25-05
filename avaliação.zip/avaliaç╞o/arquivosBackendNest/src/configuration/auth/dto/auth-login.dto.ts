import { ApiProperty } from "@nestjs/swagger";
import { IsEmail, IsNotEmpty, IsString, MinLength } from "class-validator";

export class AuthLoginDTO {
    
    @ApiProperty()
    @IsEmail()
    @IsNotEmpty()
    usuario_email:string;
}