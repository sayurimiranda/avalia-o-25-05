import { ApiProperty } from "@nestjs/swagger";
import { IsNotEmpty } from "class-validator";

export class AuthJwtTokenDto{
   
    
    @ApiProperty()
    @IsNotEmpty()
    accessToken: string;

}