import { ApiProperty } from "@nestjs/swagger";
import { IsEmail, IsNotEmpty, IsString } from "class-validator"

export class AuthTokenDto{
    
    @ApiProperty()
    @IsEmail()
    @IsNotEmpty()
    usuario_email: string
    
    @ApiProperty()
    @IsString()
    @IsNotEmpty()
    usuario_token: string
    
    constructor(email,token){
        this.usuario_email=email;
        this.usuario_token =token;
    }
}