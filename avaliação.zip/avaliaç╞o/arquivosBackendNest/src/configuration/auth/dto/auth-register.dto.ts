import { CreateUsuarioDTO } from "../../../usuario/dto/create-usuario.dto";


export class AuthRegisterDTO extends CreateUsuarioDTO {

}