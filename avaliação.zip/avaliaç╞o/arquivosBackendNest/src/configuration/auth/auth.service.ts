import { BadRequestException, ForbiddenException, Inject, Injectable, UnauthorizedException } from "@nestjs/common";

import { JwtService } from "@nestjs/jwt";
import { AuthRegisterDTO } from "./dto/auth-register.dto";
import { usuario } from "@prisma/client";
//import { MailerService } from '@nestjs-modules/mailer';
import { PrismaService } from "../prisma/prisma.service";
import { UsuarioService } from "../../usuario/usuario.service";
import { PrismaClientKnownRequestError } from "@prisma/client/runtime/library";
import { AuthLoginDTO } from "./dto/auth-login.dto";
import { AuthTokenDto } from "./dto/auth-token.dto";
import { CACHE_MANAGER } from "@nestjs/cache-manager";
import { Cache } from "cache-manager";

@Injectable()
export class AuthService {
  private issuer = "login";
  private audience = "usuarios";

  constructor(
      private readonly jwtService: JwtService,
      private readonly prisma: PrismaService,
      private readonly usuarioService: UsuarioService,
      //private readonly mailer: MailerService,
      @Inject(CACHE_MANAGER) private cacheManager: Cache,
  ) { }

  /**
   * Cria um token de acesso com base nos dados do usuário.
   * @param {usuario} usuario - Dados do usuário.
   * @returns {Object} Objeto contendo o token de acesso.
   */
  async createToken(usuario: usuario) {
      return {
          accessToken: await this.jwtService.signAsync({
              sub: usuario.usuario_id,
              usuario_nome: usuario.usuario_nome,
              usuario_email: usuario.usuario_email,
              usuario_cargo: usuario.usuario_cargo
          }, {
              expiresIn: '1 days',
              issuer: this.issuer,
              audience: this.audience
          })
      }
  }
  /**
   * Verifica a validade de um token.
   * @param {string} token - Token a ser verificado.
   * @returns {Object} Dados do token se for válido.
   * @throws {BadRequestException} Lança uma exceção se o token for inválido.
   */
  checkToken(token: string) {
    try {
      const data = this.jwtService.verify(token, {
        audience: this.audience,
        issuer: this.issuer,
      });
      return data;
    } catch (error) {
      throw new BadRequestException(error);
    }
  }

  /**
   * Verifica se um token é válido.
   * @param {string} token - Token a ser verificado.
   * @returns {boolean} true se o token for válido, false caso contrário.
   */
  isValidToken(token: string) {
      try {
          this.checkToken(token)
          return true;
      } catch (error) {
          return false;
      }
  }

  /**
   * Autentica um usuário com base no e-mail e senha fornecidos.
   * @param {AuthLoginDTO} auth_login_dto - E-mail do usuário.
   * @returns {AuthTokenDto} Retorna um AuthTokenDto.
   * @throws {UnauthorizedException} Exceção se o e-mail ou senha estiverem incorretos.
   */
  async loginEmail(auth_login_dto) {
      try {
          const usuario = await this.prisma.usuario.findFirstOrThrow({
              where:{
                  usuario_email:auth_login_dto.usuario_email
              },
              select:{
                  usuario_email:true
              }
          })

          if (usuario===null) {
              throw new ForbiddenException('Credenciais invalidas 1')
          } 

          const searchToken:string = await this.cacheManager.get(usuario.usuario_email)

          if (!searchToken) {
              var token = (Math.random() + 1).toString(36).substring(7).toUpperCase();
              while(token.length!=6){
                  token = (Math.random() + 1).toString(36).substring(7).toUpperCase();
              }
              await this.cacheManager.set(usuario.usuario_email, token, 60000)
              return new AuthTokenDto(usuario.usuario_email,token) 
          }
          else {
              return new AuthTokenDto(usuario.usuario_email,searchToken)
          } 
      } catch (error) {
          if(error instanceof PrismaClientKnownRequestError){
              if(error = 'P2025'){
                  throw new ForbiddenException('Credenciais invalidas')
              }
          }
          if (error instanceof ForbiddenException) {
              throw error
          }
      }  
  }

  async loginToken(tokendto:AuthTokenDto){
      try {
          const usuario = await this.prisma.usuario.findFirstOrThrow({
              where:{
                  usuario_email:tokendto.usuario_email
              },
          })

          if(!usuario) throw new ForbiddenException('Credenciais invalidas')

          const token:string = await this.cacheManager.get(usuario.usuario_email)
          if (!token) throw new ForbiddenException('Token não valida')

          if((token != tokendto.usuario_token)) throw new ForbiddenException('Token não valida')

          this.cacheManager.del(usuario.usuario_email)
          const tokenJWT = await this.createToken(usuario)
          console.log(tokenJWT)
          return tokenJWT
      } catch (error) {
          if(error instanceof PrismaClientKnownRequestError){
              if(error = 'P2025'){
                  throw new ForbiddenException('Credenciais invalidas')
              }
          }
          throw error
      }
  }

/**
 * Autentica um usuário com base no e-mail e senha fornecidos.
 * @param {string} email - E-mail do usuário.
 * @param {string} password - Senha do usuário.
 * @returns {Promise<any>} Promessa que resolve para o token de acesso gerado após a autenticação bem-sucedida.
 * @throws {UnauthorizedException} Exceção se o e-mail ou senha estiverem incorretos.
 */
async login(email: string, password: string) {
  const usuario = await this.prisma.usuario.findFirst({
    where: {
      usuario_email: email,
    },
  });

  if (!usuario) {
    throw new UnauthorizedException("E-mail e/ou senha incorretos.");
  }

  return this.createToken(usuario);
}

  /**
   * Envia um e-mail para redefinição de senha do usuário.
   * @param {string} email - O endereço de e-mail do usuário solicitando a redefinição de senha.
   * @returns {Promise<boolean>} - Uma Promise indicando se o e-mail de redefinição de senha foi enviado com sucesso.
   */
  async forget(email: string) {
    const usuario = await this.prisma.usuario.findFirst({
      where: {
        usuario_email: email,
      },
    });
    if (!usuario) {
      throw new UnauthorizedException("E-mail está incorreto.");
    }

    const token = this.jwtService.sign(
      {
        id: usuario.usuario_id,
      },
      {
        expiresIn: "30 minutes",
        subject: String(usuario.usuario_id),
        issuer: "forget",
        audience: "usuarios",
      },
    );
    //removido porque chama um biblioteca incompativel no docker
    //await this.mailer.sendMail({
    //    subject: 'Recuperação de Senha',
    //    to: 'mackenzie.max.rj@gmail.com',
    //    template: 'forget',
    //    context: {
    //        nome: usuario.usuario_nome,
    //        token
    //    }
    //});

    return true;
  }

  /**
   * Registra um novo usuário.
   * @param {AuthRegisterDTO} data - Dados do usuário a serem registrados.
   * @returns {Object} Objeto contendo o token de acesso.
   */
  async register(data: AuthRegisterDTO) {
    delete data.usuario_tipo;
    const usuario = await this.usuarioService.create(data);
    return this.createToken(usuario);
  }
}
