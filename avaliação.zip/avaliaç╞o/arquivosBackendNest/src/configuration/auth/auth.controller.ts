import { AuthService } from './auth.service';
import { BadRequestException, Body, Controller, FileTypeValidator, MaxFileSizeValidator, ParseFilePipe, Post, Req, UploadedFile, UploadedFiles, UseGuards, UseInterceptors } from "@nestjs/common";
import { AuthLoginDTO } from "./dto/auth-login.dto";
import { AuthRegisterDTO } from "./dto/auth-register.dto";
import { AuthForgetDTO } from "./dto/auth-forget.dto";
import { User } from '../decorators/user.decorator';
import { FileFieldsInterceptor, FileInterceptor, FilesInterceptor } from '@nestjs/platform-express';
import { AuthGuard } from '../guards/auth.guard';
import { UsuarioService } from '../../usuario/usuario.service';
import { FileService } from '../../file/file.service';
import { AuthTokenDto } from './dto/auth-token.dto';
import { Public } from '../decorators/public.decorator';
import { AuthJwtTokenDto } from './dto/auth-JWT-token.dto';


@Controller('auth')
export class AuthController {

    constructor(
        private readonly usuarioService: UsuarioService,
        private readonly authService: AuthService,
        private readonly fileService: FileService
    ) { }

    /**
     * Rota para login usando email de usuário.
     * @param {AuthLoginDTO} auth_login_dto - Dados para login do usuário.
     * @returns {Promise<AuthTokenDTO>} Promessa que resolve para o token de acesso do usuário.
     */

    @Public()
    @Post('login_email')
    async login(@Body() auth_login_dto: AuthLoginDTO) {
        return await this.authService.loginEmail(auth_login_dto)
    }
    /**
     * Rota para login usando token gerado a partir do login() de usuário.
     * @param {AuthLoginDTO} auth_login_dto - Dados para login do usuário.
     * @returns {Promise<AuthTokenDTO>} Promessa que resolve para o token de acesso do usuário.
     */
    
    @Public()
    @Post('login_token')
    async loginToken(@Body() auth_token_dto: AuthTokenDto) {
        return await this.authService.loginToken(auth_token_dto)
    }

    /**
     * Rota para registro de novo usuário.
     * @param {AuthRegisterDTO} body - Dados para registro do novo usuário.
     * @returns {Promise<any>} Promessa que resolve para o token de acesso do usuário registrado.
     */
    // @Post('register')
    // async register(@Body() body: AuthRegisterDTO) {
    //     return this.authService.register(body);
    // }

    @Public()
    @Post('check_jwt')
    async checkJWT(@Body() jwt: AuthJwtTokenDto) {
        try {
            const data = await this.authService.checkToken(jwt.accessToken)
            if (data) {
                return true
            }
        } catch (err) {
            return false
        }
         
        
    }
    /**
     * Rota para solicitar redefinição de senha.
     * @param {AuthForgetDTO} body - Dados para solicitar redefinição de senha.
     * @returns {Promise<boolean>} Promessa que resolve para true se a solicitação for bem-sucedida.
     */
    @Post('forget')
    async forget(@Body() { email }: AuthForgetDTO) {
        return this.authService.forget(email);
    }

    /**
     * Rota para obter informações do usuário autenticado.
     * @param {User} user - Usuário autenticado extraído do token.
     * @returns {Promise<any>} Promessa que resolve para os detalhes do usuário autenticado.
     */
    
    @Post('me')
    async me(@User() user, @Req() { tokenPayload }) {
        return { user, tokenPayload };
    }

    @UseInterceptors(FileInterceptor('file'))
    @Post('photo')
    async uploadPhoto(
        @User() user,
        @UploadedFile(new ParseFilePipe({
            validators: [
                new FileTypeValidator({ fileType: 'image/png' }),
                new MaxFileSizeValidator({ maxSize: 1024 * 50 })
            ]
        })) photo: Express.Multer.File) {

        const filename = `photo-${user.id}.png`

        try {
            await this.fileService.upload(photo, filename);
        } catch (error) {
            throw new BadRequestException(error)

        }
        return { sucess: true };
    }

    @UseInterceptors(FilesInterceptor('files'))
    @Post('files')
    async uploadFiles(@User() user, @UploadedFiles() files: Express.Multer.File[]) {
        return files;
    }

    @UseInterceptors(FileFieldsInterceptor([
        { name: 'photo', maxCount: 1 },
        { name: 'documents', maxCount: 10 }
    ]))
    @Post('files-fields')
    async uploadFilesFields(@UploadedFiles() files: { photo: Express.Multer.File, documents: Express.Multer.File[] }) {
        return files;
    }
}