import { CanActivate, ExecutionContext, ForbiddenException, Injectable } from "@nestjs/common";
import { Reflector } from "@nestjs/core";
import { Observable } from "rxjs";
import { Roles } from "../decorators/roles.decorator";

@Injectable()
export class RoleGuard implements CanActivate{
    constructor(private reflector:Reflector){}

    canActivate(context: ExecutionContext): boolean | Promise<boolean> | Observable<boolean> {
        const role = this.reflector.get(Roles,context.getHandler())
        if(!role){
            return true;
        }
        const req = context.switchToHttp().getRequest()
        const cargo = req.user.usuario_cargo
        console.log(cargo)
        return this.matchRole(role,cargo)
    }
    
    matchRole(roles:string[],role:string){
        if(roles.includes(role)){
            return true
        }else{
           throw new ForbiddenException('Papel Inválido')
        }
    }
}