import { Injectable, NotFoundException } from '@nestjs/common';
import { CreateRelatorioDto } from './dto/create-relatorio.dto';
import { UpdateRelatorioDto } from './dto/update-relatorio.dto';
import { PrismaService } from 'src/configuration/prisma/prisma.service';
import { Arquivo } from 'src/arquivo/entities/arquivo.entity';
import { FindByPeriodDto } from './dto/find-by-period.dto';

@Injectable()
export class RelatorioService {

    constructor(private readonly prisma: PrismaService) { }


    async findByTag(tag: string) {
        return this.prisma.$queryRaw //Desenvolver método de busca usando tags
            `SELECT  tag.tag_id, tag.tag_nome, projeto.projeto_id, arquivo_tag.arquivo_id, arquivo.arquivo_id
            FROM permissionamento
            INNER JOIN usuario 
            ON permissionamento.usuario_id = usuario.usuario_id 
            INNER JOIN tag
            ON arquivo_tag.arquivo_tag_id = arquivo.arquivo_id
            WHERE tag.tag_nome = ${tag}
            GROUP BY tag.tag_id`
    }

    async findByProject(status: number) {
        return this.prisma.$queryRaw
            ` SELECT projeto.projeto_id, projeto.projeto_status, empresa.empresa_nome, empresa.empresa_nome, relatorio.relatorio_status
                FROM permissionamento
                INNER JOIN usuario 
                ON permissionamento.usuario_id = usuario.usuario_id
                INNER JOIN projeto_usuario 
                ON projeto.projeto_status = projeto_usuario.projeto_usuario_status
                INNER JOIN relatorio
                WHERE projeto.projeto_status = ${status}
                GROUP BY relatorio.relatorio_status`
    }

    // Método para buscar relatórios por período
    async findByPeriod(findByPeriodDto: FindByPeriodDto) {
        const { startDate, endDate } = findByPeriodDto;
        return this.prisma.$queryRaw
            `
            SELECT arquivo.arquivo_descricao,
            arquivo.arquivo_data,
            arquivo.arquivo_versao,
            arquivo.arquivo_link,
            arquivo.arquivo_extensao,
            arquivo.arquivo_status
            FROM permissionamento
            LEFT JOIN usuario ON permissionamento.usuario_id = usuario.usuario_id
            LEFT JOIN disciplina ON permissionamento.disciplina_id = disciplina.disciplina_id
            LEFT JOIN grupo ON permissionamento.grupo_id = grupo.grupo_id
            LEFT JOIN arquivo ON permissionamento.arquivo_id = arquivo.arquivo_id
            LEFT JOIN etapa ON permissionamento.etapa_id = etapa.etapa_id
            LEFT JOIN projeto ON permissionamento.projeto_id = projeto.projeto_id
            
    `//WHERE arquivo.arquivo_data BETWEEN ${new Date(startDate)} AND ${new Date(endDate)};
    }

    async create(data: CreateRelatorioDto) {
        return this.prisma.relatorio.create({ data });
    }

    async findAll() {
        return this.prisma.relatorio.findMany();
    }

    async findById(id: number) {
        await this.exists(id);
        return this.prisma.relatorio.findUnique({
            where: {
                relatorio_id: id
            }
        }
        );
    }


    async updatePut(id: number, data: any) {
        await this.exists(id);
        return this.prisma.relatorio.update({
            data,
            where: {
                relatorio_id: id
            }
        }
        );
    }


    async updatePatch(id: number, data: any) {
        await this.exists(id);
        return this.prisma.relatorio.update({
            data,
            where: {
                relatorio_id: id
            }
        });
    }

    async delete(id: number) {
        await this.exists(id);
        return this.prisma.relatorio.delete({
            where: {
                relatorio_id: id
            }
        }
        );
    }

    async exists(id: number) {
        if (!(await this.prisma.relatorio.count({
            where: {
                relatorio_id: id
            }
        }
        )
        )
        ) {
            throw new NotFoundException(`O relatório ${id} não existe.`);
        }
    }
}
