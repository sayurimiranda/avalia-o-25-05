import { Module, forwardRef } from '@nestjs/common';
import { RelatorioService } from './relatorio.service';
import { RelatorioController } from './relatorio.controller';
import { PrismaModule } from 'src/configuration/prisma/prisma.module';
import { AuthModule } from 'src/configuration/auth/auth.module';

@Module({
  imports: [PrismaModule, forwardRef(() => AuthModule)],
  controllers: [RelatorioController],
  providers: [RelatorioService],
  exports: [RelatorioService]
})
export class RelatorioModule {}
