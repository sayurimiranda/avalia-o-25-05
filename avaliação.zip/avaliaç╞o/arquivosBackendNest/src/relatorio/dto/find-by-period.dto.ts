import { IsDateString } from 'class-validator';

export class FindByPeriodDto {
    @IsDateString()
    startDate: string;

    @IsDateString()
    endDate: string;
}