import { ApiProperty } from "@nestjs/swagger";

export class CreateRelatorioDto {

    @ApiProperty()
    relatorio_id: number;

    @ApiProperty()
    relatorio_descricao: string;

    @ApiProperty()
    relatorio_tipo: string;

    @ApiProperty()
    projeto_id: number;

    @ApiProperty()
    relatorio_json: string;

}
