import { Controller, Get, Post, Body, Patch, Param, Delete, ParseIntPipe, Put, BadRequestException, Query, ValidationPipe } from '@nestjs/common';
import { RelatorioService } from './relatorio.service';
import { CreateRelatorioDto } from './dto/create-relatorio.dto';
import { UpdateRelatorioDto } from './dto/update-relatorio.dto';
import { ParamId } from 'src/configuration/decorators/param-id.decorator';
import { FindByPeriodDto } from './dto/find-by-period.dto';

@Controller('relatorio')
export class RelatorioController {
  constructor(private relatorioService: RelatorioService) { }

  @Get('by-period')
  async findByPeriod(@Query(new ValidationPipe({ transform: true })) findByPeriodDto: FindByPeriodDto) {
    if (!findByPeriodDto.startDate || !findByPeriodDto.endDate) {
      throw new BadRequestException('startDate and endDate query parameters are required');
    }

    return this.relatorioService.findByPeriod(findByPeriodDto);
  }

  @Get('tags/:tag')
  async findByTag(@Param('tag') tag: string) {
    return this.relatorioService.findByTag(tag);
  }

  @Post()
  async create(@Body() data: CreateRelatorioDto) {
    return this.relatorioService.create(data);
  }

  @Get()
  async getAll() {
    return this.relatorioService.findAll();
  }

  @Get(':id')
  async findById(@ParamId() id: number) {
    return this.relatorioService.findById(id);
  }

  @Put(':id')
  async updatePut(@Body() data: any, @Param('id', ParseIntPipe) id: number) {
    return this.relatorioService.updatePut(id, data);
  }

  @Patch(':id')
  async updatePatch(@Body() data: any, @Param('id', ParseIntPipe) id: number) {
    return this.relatorioService.updatePatch(id, data);
  }

  @Delete(':id')
  async delete(@Param('id', ParseIntPipe) id: number) {
    return this.relatorioService.delete(id);
  }
}
