export class ListaCompartilhada {}
