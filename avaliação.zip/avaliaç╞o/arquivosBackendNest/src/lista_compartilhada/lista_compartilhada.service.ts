import { Injectable, NotFoundException } from "@nestjs/common";
import { PrismaService } from "src/configuration/prisma/prisma.service";
import { CreateListaCompartilhadaDto } from "./dto/create-lista_compartilhada.dto";
import { UpdateListaCompartilhadaDto } from "./dto/update-lista_compartilhada.dto";

@Injectable()
export class ListaCompartilhadaService {

  constructor(private readonly prisma: PrismaService) { }

  async create(createListaCompartilhadaDto: CreateListaCompartilhadaDto) {
    return this.prisma.lista_compartilhada.create({ data: createListaCompartilhadaDto });
  }


  async findAll() {
    return this.prisma.lista_compartilhada.findMany();
  }

  async findAllListasCompartilhadas(usuario_id: number) {
    return this.prisma.$queryRaw`SELECT * FROM lista_compartilhada as lc
    JOIN lista_compartilhada_arquivo as lca
    on lc.lista_compartilhada_id = lca.lista_compartilhada_id
    JOIN permissionamento as p
    on lca.permissionamento_id = p.permissionamento_id
    JOIN usuario as u
    on p.usuario_id = u.usuario_id
    LEFT JOIN arquivo as a
    on p.arquivo_id = a.arquivo_id
    LEFT JOIN etapa as e
    on p.etapa_id = e.etapa_id
    LEFT JOIN disciplina as d
    on p.disciplina_id = d.disciplina_id
    LEFT JOIN projeto as pro
    on p.projeto_id = pro.projeto_id
    where u.usuario_id = ${usuario_id} and lc.lista_compartilhada_status >= 0
    `;
  }
  async findListaCompartilhadaById(usuario_id: number, lista_compartilhada_id: number) {
    return this.prisma.$queryRaw`SELECT * FROM lista_compartilhada as lc
    JOIN lista_compartilhada_arquivo as lca
    on lc.lista_compartilhada_id = lca.lista_compartilhada_id
    JOIN permissionamento as p
    on lca.permissionamento_id = p.permissionamento_id
    JOIN usuario as u
    on p.usuario_id = u.usuario_id
    LEFT JOIN arquivo as a
    on p.arquivo_id = a.arquivo_id
    LEFT JOIN etapa as e
    on p.etapa_id = e.etapa_id
    LEFT JOIN disciplina as d
    on p.disciplina_id = d.disciplina_id
    LEFT JOIN projeto as pro
    on p.projeto_id = pro.projeto_id
    where u.usuario_id = ${usuario_id}
    and lc.lista_compartilhada_id = ${lista_compartilhada_id}
    `;
  }


  async exists(id: number) {
    if (
      !(await this.prisma.empresa.count({
        where: {
          empresa_id: id, // Altere 'usuario_id' para 'empresa_id'
        },
      }))
    ) {
      throw new NotFoundException(`A lista Compartilhada ${id} não existe.`); // Ajuste a mensagem de erro para empresa
    }
  }

  async update(id: number, data: any) {
    await this.exists(id);
    return this.prisma.lista_compartilhada.update({
      // Altere 'usuario' para 'empresa'
      data,
      where: {
        lista_compartilhada_id: id, // Altere 'usuario_id' para 'empresa_id'
      },
    });
  }

  async remove(id: number) {
    await this.exists(id);
    return this.prisma.lista_compartilhada.delete({
      // Altere 'usuario' para 'empresa'
      where: {
        lista_compartilhada_id: id, // Altere 'usuario_id' para 'empresa_id'
      },
    });
  }
}
