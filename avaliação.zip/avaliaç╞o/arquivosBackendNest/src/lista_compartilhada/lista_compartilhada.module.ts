import { Module } from '@nestjs/common';
import { ListaCompartilhadaService } from './lista_compartilhada.service';
import { ListaCompartilhadaController } from './lista_compartilhada.controller';
import { PrismaModule } from "src/configuration/prisma/prisma.module";


@Module({
  imports: [PrismaModule],
  controllers: [ListaCompartilhadaController],
  providers: [ListaCompartilhadaService],
})
export class ListaCompartilhadaModule {}
