import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { ListaCompartilhadaService } from './lista_compartilhada.service';
import { CreateListaCompartilhadaDto } from './dto/create-lista_compartilhada.dto';
import { UpdateListaCompartilhadaDto } from './dto/update-lista_compartilhada.dto';

@Controller('lista-compartilhada')
export class ListaCompartilhadaController {
  constructor(private readonly listaCompartilhadaService: ListaCompartilhadaService) {}

  @Post()
  create(@Body() createListaCompartilhadaDto: CreateListaCompartilhadaDto) {
    return this.listaCompartilhadaService.create(createListaCompartilhadaDto);
  }

  @Get()
  findAll() { 
    return this.listaCompartilhadaService.findAll();
  }


  @Get(':usuario_id')
  findByUser(@Param('usuario_id') usuario_id: string) {
    return this.listaCompartilhadaService.findAllListasCompartilhadas(+usuario_id);
  }

  @Get(':usuario_id/:lista_compartilhada_id')
  findByListId(@Param('usuario_id') usuario_id: string, @Param('lista_compartilhada_id') lista_compartilhada_id: string){
    return this.listaCompartilhadaService.findListaCompartilhadaById(+usuario_id, +lista_compartilhada_id);
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() updateListaCompartilhadaDto: UpdateListaCompartilhadaDto) {
    return this.listaCompartilhadaService.update(+id, updateListaCompartilhadaDto);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.listaCompartilhadaService.remove(+id);
  }
}
