import { Test, TestingModule } from '@nestjs/testing';
import { ListaCompartilhadaService } from './lista_compartilhada.service';

describe('ListaCompartilhadaService', () => {
  let service: ListaCompartilhadaService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [ListaCompartilhadaService],
    }).compile();

    service = module.get<ListaCompartilhadaService>(ListaCompartilhadaService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
