import { Test, TestingModule } from '@nestjs/testing';
import { ListaCompartilhadaController } from './lista_compartilhada.controller';
import { ListaCompartilhadaService } from './lista_compartilhada.service';

describe('ListaCompartilhadaController', () => {
  let controller: ListaCompartilhadaController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [ListaCompartilhadaController],
      providers: [ListaCompartilhadaService],
    }).compile();

    controller = module.get<ListaCompartilhadaController>(ListaCompartilhadaController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
