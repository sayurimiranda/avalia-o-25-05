import { PartialType } from '@nestjs/swagger';
import { CreateListaCompartilhadaDto } from './create-lista_compartilhada.dto';

export class UpdateListaCompartilhadaDto extends PartialType(CreateListaCompartilhadaDto) {}
