export class CreateListaCompartilhadaDto {}
