export class Arquivo {}
