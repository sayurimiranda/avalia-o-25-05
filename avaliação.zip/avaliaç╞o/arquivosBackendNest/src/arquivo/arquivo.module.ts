import { Module } from "@nestjs/common";
import { ArquivoService } from "./arquivo.service";
import { ArquivoController } from "./arquivo.controller";
import { PrismaModule } from "src/configuration/prisma/prisma.module";
import { ComentarioModule } from "src/comentario/comentario.module";
import { NotificacaoModule } from "src/notificacao/notificacao.module";

@Module({
  controllers: [ArquivoController],
  imports: [PrismaModule, ComentarioModule, NotificacaoModule],
  providers: [ArquivoService],
})
export class ArquivoModule {}
