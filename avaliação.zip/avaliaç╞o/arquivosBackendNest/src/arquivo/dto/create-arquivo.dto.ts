import { IsOptional, IsInt, IsString, IsDate, IsNumber } from "class-validator";
import { ApiProperty } from "@nestjs/swagger";

export class CreateArquivoDto {
  @ApiProperty()
  @IsInt()
  usuario_id: number;

  @ApiProperty()
  @IsString()
  @IsOptional()
  arquivo_descricao?: string;

  @ApiProperty()
  @IsDate()
  @IsOptional()
  arquivo_data?: Date;

  @ApiProperty()
  @IsString()
  @IsOptional()
  arquivo_extensao?: string;

  @ApiProperty()
  @IsNumber()
  @IsOptional()
  arquivo_status?: number;

  @ApiProperty()
  @IsOptional()
  @IsNumber()
  arquivo_versao?: number;

  @ApiProperty()
  @IsString()
  @IsOptional()
  arquivo_link?: string;

  @ApiProperty()
  @IsInt()
  @IsOptional()
  local_id?: number;

  @ApiProperty()
  @IsInt()
  projeto_id: number;

  @ApiProperty()
  @IsInt()
  @IsOptional()
  etapa_id?: number;

  @ApiProperty()
  @IsString()
  @IsOptional()
  arquivo_id_pai?: string;
}
