import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
} from "@nestjs/common";
import { ArquivoService } from "./arquivo.service";
import { CreateArquivoDto } from "./dto/create-arquivo.dto";
import { UpdateArquivoDto } from "./dto/update-arquivo.dto";
import { ApiOperation } from "@nestjs/swagger";

@Controller("arquivo")
export class ArquivoController {
  constructor(private readonly arquivoService: ArquivoService) { }

  @Post()
  create(@Body() createArquivoDto: CreateArquivoDto) {
    return this.arquivoService.create(createArquivoDto);
  }

  @Get()
  findAll() {
    return this.arquivoService.findAll();
  }

  @Get("version/:id")
  getFilesEndVersion(@Param("id") id: string) {
    return this.arquivoService.getLastVersion(id);
  }

  @Get(":id")
  findOne(@Param("id") id: string) {
    return this.arquivoService.findOne(id);
  }

  @Patch(":id")
  update(@Param("id") id: string, @Body() updateArquivoDto: UpdateArquivoDto) {
    return this.arquivoService.update(id, updateArquivoDto);
  }

  @Delete(":id")
  remove(@Param("id") id: string) {
    return this.arquivoService.remove(id);
  }

  @Get("versoes/:id")
  getfileVersion(@Param("id") id: string) {
    return this.arquivoService.getfileVersion(id);
  }

  @Get("ArquivosPorUsuario/:id")
  @ApiOperation({ summary: "Arquivos que um usuário tenha permissão" })
  getfileList(@Param("id") id: string) {
    return this.arquivoService.getfileList(id);
  }

  @Get("ArquivoUltimaVersao/:project/:description")
  getFileVersion(
    @Param("project") project: string,
    @Param("description") description: string,
  ) {
    return this.arquivoService.getFileVersion(project, description);
  }

  @Get("ArquivosPorProjeto/:id/:projeto")
  @ApiOperation({ summary: "Todos os arquivos de um projeto" })
  getListFileByProject(
    @Param("project_id") projeto_id: string,
    @Param("id") id: string,
  ) {
    return this.arquivoService.getListFileByProject(projeto_id, id);
  }

  @Get("ListaArquivosComAutor/:status")
  @ApiOperation({ summary: "Lista de Arquivos com o Nome de Usuário" })
  getFilesWithAutor(@Param("status") arquivo_status: string) {
    return this.arquivoService.getFilesWithAutor(arquivo_status);
  }
  @Get('ListaArquivosPais/:status')
  @ApiOperation({ summary: "Lista de Arquivos Pai" })
  getParentFiles(
    @Param('status') arquivo_status: string,
  ) {
    return this.arquivoService.getParentFiles(arquivo_status);
  }
}
