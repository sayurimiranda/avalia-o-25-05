import { Injectable } from "@nestjs/common";
import { CreateArquivoDto } from "./dto/create-arquivo.dto";
import { UpdateArquivoDto } from "./dto/update-arquivo.dto";
import { PrismaService } from "src/configuration/prisma/prisma.service";
import { NotFoundException } from "@nestjs/common";

export const INITIAL_VERSION = 0;
@Injectable()
export class ArquivoService {
  constructor(private readonly prisma: PrismaService) { }
  async create(createArquivoDto: CreateArquivoDto) {
    // verificando se o orquivo existe na mesma etapa
    const verificaArquivo = await this.prisma.arquivo.findFirst({
      where: {
        etapa_id: createArquivoDto.etapa_id,
        arquivo_descricao: createArquivoDto.arquivo_descricao,
      },
      orderBy: {
        arquivo_versao: "desc",
      },
    });
    // se ele não existe eu crio
    if (!verificaArquivo) {
      createArquivoDto.arquivo_versao = 0;
      createArquivoDto.arquivo_data = new Date();
      createArquivoDto.arquivo_status = 1;
      const novoArquivo = await this.prisma.arquivo.create({
        data: createArquivoDto,
      });
      if (novoArquivo) {
        const usuarios = await this.getUsersWithPermission(
          createArquivoDto.etapa_id,
        );
        for (const usuario of usuarios) {
          const responseNotificationVersion =
            await this.prisma.notificacao.create({
              data: {
                notificacao_titulo: "Novo Arquivo",
                notificacao_descricao: `Arquivo ${novoArquivo.arquivo_descricao} foi criado`,
                notificacao_status: 1,
                notificacao_data: new Date(),
                usuario: {
                  connect: {
                    usuario_id: usuario.usuario_id,
                  },
                },
              },
            });
          if (!responseNotificationVersion) {
            throw new NotFoundException(
              "Erro ao inserir notificação de novo de Arquivo",
            );
          }
        }
        return novoArquivo;
        // se ele  existe eu versiono
      }
    } else {
      createArquivoDto.arquivo_versao =
        Number(verificaArquivo.arquivo_versao) + 1;
      createArquivoDto.arquivo_descricao = verificaArquivo.arquivo_descricao;
      createArquivoDto.arquivo_data = new Date();
      createArquivoDto.local_id = verificaArquivo.local_id;
      createArquivoDto.arquivo_id_pai =
        verificaArquivo.arquivo_id_pai == null
          ? verificaArquivo.arquivo_id
          : verificaArquivo.arquivo_id_pai;
      const versionarArquivo = await this.prisma.arquivo.create({
        data: createArquivoDto,
      });
      if (!versionarArquivo) {
        throw new NotFoundException("Erro ao versionar Arquivo");
      }
      // Buscar todos os usuários que estão na mesma disciplina
      const usuarios = await this.getUsersWithPermission(
        versionarArquivo.etapa_id,
      );
      // Iterar sobre a lista de usuários e criar uma notificação para cada um
      for (const usuario of usuarios) {
        const responseNotificationVersion =
          await this.prisma.notificacao.create({
            data: {
              notificacao_titulo: "Novo Arquivo",
              notificacao_descricao: `Arquivo ${versionarArquivo.arquivo_descricao} foi Versionado`,
              notificacao_status: 1,
              notificacao_data: new Date(),
              usuario: {
                connect: {
                  usuario_id: usuario.usuario_id,
                },
              },
            },
          });

        if (!responseNotificationVersion) {
          throw new NotFoundException(
            "Erro ao inserir notificação de versionametno de Arquivo",
          );
        }
      }
      const response = versionarArquivo;
      return {
        ...response,
        notificacao: "",
      };
    }
  }

  findAll() {
    return this.prisma.arquivo.findMany({
      where: {
        arquivo_status: {
          gte: 0,
        },
      },
    });
  }

  findOne(id: string) {
    return this.prisma.arquivo.findUnique({
      where: {
        arquivo_id: id,
        arquivo_status: {
          gte: 0,
        },
      },
    });
  }

  update(id: string, updateArquivoDto: UpdateArquivoDto) {
    return this.prisma.arquivo.update({
      where: { arquivo_id: id },
      data: updateArquivoDto,
    });
  }

  remove(id: string) {
    return this.prisma.arquivo.update({
      where: { arquivo_id: id },
      data: {
        arquivo_status: -1,
      },
    });
  }

  // Versionamento de Arquivos
  // Função para buscar a última versão de um arquivo''''''''''''''''''''''''
  getLastVersion(id: string) {
    const arquivoPai = this.prisma.arquivo.findFirst({
      where: {
        OR: [{ arquivo_id: id }, { arquivo_id_pai: id }],
      },
      orderBy: {
        arquivo_versao: "desc",
      },
    });

    if (!arquivoPai) {
      throw new NotFoundException(
        "Arquivo Não encontrado ou não possui versões anteriores",
      );
    }
    return arquivoPai;
  }

  async getfileVersion(id: string) {
    const response = await this.prisma.arquivo.findMany({
      where: {
        OR: [{ arquivo_id: id }, { arquivo_id_pai: id }],
      },
      orderBy: {
        arquivo_versao: "desc", // ou 'desc' para ordem decrescente
      },
    });
    if (!response) {
      throw new NotFoundException("não possui versões ");
    }
    return response;
  }
  // retorna todos os usuários que tem permissão para acessar a disciplina
  async getUsersWithPermission(etapa_id: number) {
    const etapa = await this.prisma.etapa.findFirst({
      where: {
        etapa_id: etapa_id,
      },
    });
    const response = await this.prisma.usuario.findMany({
      where: {
        usuario_status: 1,
        permissionamento: {
          some: {
            disciplina: {
              disciplina_id: etapa.disciplina_id,
            },
          },
        },
      },
    });

    if (!response) {
      throw new NotFoundException(
        "Nenhum usuário com permissão para esta disciplina foi encontrado",
      );
    }

    return response;
  }

  getfileList(id: string) {
    return this.prisma.$queryRaw`SELECT
            a.arquivo_id,
            a.arquivo_descricao,
            a.arquivo_versao,
            u.usuario_nome AS autor,
            per.permissionamento_tipo,
            c.arquivo_comentario_descricao 
        FROM arquivo a
        INNER JOIN usuario u ON u.usuario_id = a.usuario_id
        INNER JOIN permissionamento per ON per.arquivo_id = a.arquivo_id
        LEFT JOIN arquivo_comentario c ON c.arquivo_id = a.arquivo_id
        WHERE (
            per.usuario_id = ${id}
            AND per.grupo_id IN (
                SELECT grupo_id FROM grupo WHERE grupo_nome IN ('Engenheiros', 'Arquitetos')
            )
        )
        ORDER BY a.arquivo_descricao`;
  }

  getFileVersion(project: string, description: string) {
    return this.prisma.$queryRaw`
    SELECT
    a.arquivo_id,
    MAX(a.arquivo_versao) AS arquivo_versao,
    MAX(a.arquivo_data) AS arquivo_data,
    u.usuario_nome AS autor,
    u.usuario_id,
    a.arquivo_descricao,
    c.arquivo_comentario_descricao
    FROM arquivo a
    INNER JOIN usuario u ON u.usuario_id = a.usuario_id
    LEFT JOIN arquivo_comentario c ON c.arquivo_id = a.arquivo_id
    WHERE a.projeto_id = ${project}
    AND a.arquivo_descricao = ${description}
    ORDER BY a.arquivo_versao DESC;`;
  }

  getListFileByProject(project: string, id: string) {
    return this.prisma.$queryRaw`
    SELECT
    a.arquivo_id,
    a.arquivo_descricao,
    a.arquivo_versao,
    a.arquivo_link,
    a.arquivo_data
    FROM arquivo a
    JOIN projeto p ON a.projeto_id = p.projeto_id
    inner join permissionamento per on per.arquivo_id = a.arquivo_id and per.usuario_id = ${id}
    WHERE p.projeto_id = ${project} 
    ORDER BY a.arquivo_data DESC;`;
  }

  getFilesWithAutor(arquivo_status: string) {
    return this.prisma.$queryRaw`
    SELECT arquivo_id, u.usuario_nome as autor, a.usuario_id, u.usuario_cargo, arquivo_descricao, arquivo_data, arquivo_versao, 
    arquivo_link, arquivo_extensao, arquivo_status, local_id, projeto_id, etapa_id, arquivo_id_pai
    FROM arquivo a 
    inner join usuario u on a.usuario_id = u.usuario_id 
    where arquivo_status = ${arquivo_status}`;
  }
  getParentFiles(arquivo_status: string) {
    return this.prisma.$queryRaw`
    SELECT arquivo_id, u.usuario_nome as autor, a.usuario_id, u.usuario_cargo, arquivo_descricao, arquivo_data, arquivo_versao, 
    arquivo_link, arquivo_extensao, arquivo_status, local_id, projeto_id, etapa_id, arquivo_id_pai
    FROM arquivo a 
    inner join usuario u on a.usuario_id = u.usuario_id 
    where arquivo_status = ${arquivo_status} and arquivo_id_pai IS NULL `;
  }

}
