export enum Role {
  User = 1,
  Admin = 2,
}

export enum Status {
  deleted = -1,
  inactive = 0,
  active = 1,
}
