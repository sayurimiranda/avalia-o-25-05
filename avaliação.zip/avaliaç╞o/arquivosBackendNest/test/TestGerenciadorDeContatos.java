import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

// Conteúdo do arquivo TestGerenciadorDeContatos.java

public class TestGerenciadorDeContatos {
    private GerenciadorDeContatos gerenciador;

    @Before
    public void setUp() {
        gerenciador = new GerenciadorDeContatos();
        gerenciador.adicionarContato(1, "Alice", "123456789");
        gerenciador.adicionarContato(2, "Bob", "987654321");
    }

    @After
    public void tearDown() {
        gerenciador = null;
    }

    @Test
    public void testAdicionarContatoSucesso() {
        gerenciador.adicionarContato(3, "Charlie", "555555555");
        Contato contato = gerenciador.pesquisarContatoPorId(3);
        assertEquals("Charlie", contato.getNome());
        assertEquals("555555555", contato.getTelefone());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAdicionarContatoDuplicado() {
        gerenciador.adicionarContato(1, "Duplicate", "000000000");
    }

    @Test
    public void testRemoverContatoSucesso() {
        gerenciador.removerContato(1);
        try {
            gerenciador.pesquisarContatoPorId(1);
            fail("Deveria ter lançado IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // Esperado
        }
    }

    @Test(expected = IllegalArgumentException.class)
    public void testRemoverContatoInexistente() {
        gerenciador.removerContato(99);
    }

    @Test
    public void testPesquisarContatoPorIdSucesso() {
        Contato contato = gerenciador.pesquisarContatoPorId(1);
        assertEquals("Alice", contato.getNome());
        assertEquals("123456789", contato.getTelefone());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testPesquisarContatoPorIdInexistente() {
        gerenciador.pesquisarContatoPorId(99);
    }
}
